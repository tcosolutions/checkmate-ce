issues_data = {
    "I001": {
        "title": "Perl insecurity",
        "description": "%(issue.data)s",
        "severity": 3,
        "categories": []
    }
}
