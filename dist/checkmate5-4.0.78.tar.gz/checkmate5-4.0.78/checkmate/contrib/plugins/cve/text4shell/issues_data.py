issues_data = {
    "I001": {
        "title": "Text4Shell",
        "description": "%(issue.data)s",
        "severity": 3,
        "categories": []
    }
}
