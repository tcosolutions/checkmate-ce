# exceptions.py

class ConfigurationError(Exception):
    """Custom exception for configuration errors."""
    pass

